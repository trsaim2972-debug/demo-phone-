package com.example.tempnumbersms

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Interceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query
import com.google.gson.annotations.SerializedName

data class NumberItem(
    val id: Long,
    val phoneNumber: String,
    val label: String,
    val active: Boolean
)
data class NumbersResponse(val numbers: List<NumberItem>)
data class SmsMessage(
    val id: Long,
    val sender: String,
    val body: String,
    @SerializedName("receivedAt") val receivedAt: String
)
data class MessagesResponse(val messages: List<SmsMessage>)

interface SmsApi {
    @GET("api/numbers")
    suspend fun numbers(): NumbersResponse

    @GET("api/numbers/{id}/messages")
    suspend fun messages(
        @Path("id") id: Long,
        @Query("limit") limit: Int = 30
    ): MessagesResponse
}

private val api: SmsApi by lazy {
    val auth = Interceptor { chain ->
        val request = chain.request().newBuilder()
            .header("Authorization", "Bearer ${BuildConfig.DEV_API_TOKEN}")
            .build()
        chain.proceed(request)
    }
    val client = OkHttpClient.Builder().addInterceptor(auth).build()
    Retrofit.Builder()
        .baseUrl(BuildConfig.API_BASE_URL)
        .client(client)
        .addConverterFactory(GsonConverterFactory.create())
        .build()
        .create(SmsApi::class.java)
}

class SmsViewModel : ViewModel() {
    var numbers by mutableStateOf<List<NumberItem>>(emptyList())
        private set
    var messages by mutableStateOf<List<SmsMessage>>(emptyList())
        private set
    var selected by mutableStateOf<NumberItem?>(null)
        private set
    var loading by mutableStateOf(false)
        private set
    var error by mutableStateOf<String?>(null)
        private set

    init { refreshNumbers() }

    fun refreshNumbers() {
        viewModelScope.launch {
            loading = true
            error = null
            try {
                numbers = api.numbers().numbers
                if (selected == null) numbers.firstOrNull()?.let { select(it) }
            } catch (e: Exception) {
                error = "সার্ভারে সংযোগ করা যায়নি। Backend চালু আছে কি না দেখুন।"
            } finally { loading = false }
        }
    }

    fun select(item: NumberItem) {
        selected = item
        viewModelScope.launch {
            loading = true
            error = null
            try { messages = api.messages(item.id).messages }
            catch (e: Exception) { error = "SMS লোড করা যায়নি।"; messages = emptyList() }
            finally { loading = false }
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val vm = SmsViewModel()
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) {
                    SmsHome(vm)
                }
            }
        }
    }
}

@Composable
fun SmsHome(vm: SmsViewModel) {
    var showNumbers by remember { mutableStateOf(true) }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Temp Number SMS") },
                actions = {
                    TextButton(onClick = { vm.refreshNumbers() }) { Text("Refresh") }
                }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).padding(16.dp).fillMaxSize()) {
            Text("অনুমোদিত নম্বরের SMS ইনবক্স", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            vm.error?.let {
                Text(it, color = MaterialTheme.colorScheme.error)
                Spacer(Modifier.height(8.dp))
            }
            if (vm.loading) LinearProgressIndicator(Modifier.fillMaxWidth())
            TextButton(onClick = { showNumbers = !showNumbers }) {
                Text(if (showNumbers) "নম্বরের তালিকা লুকান" else "নম্বরের তালিকা দেখান")
            }
            if (showNumbers) {
                LazyColumn(Modifier.heightIn(max = 180.dp)) {
                    items(vm.numbers, key = { it.id }) { number ->
                        ListItem(
                            headlineContent = { Text(number.phoneNumber) },
                            supportingContent = { Text(number.label.ifBlank { "SMS নম্বর" }) },
                            modifier = Modifier.clickable { vm.select(number) }
                        )
                        HorizontalDivider()
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Text(
                vm.selected?.let { "ইনবক্স: ${it.phoneNumber}" } ?: "কোনো নম্বর নেই",
                style = MaterialTheme.typography.titleMedium
            )
            Spacer(Modifier.height(8.dp))
            if (vm.messages.isEmpty() && !vm.loading) {
                Text("এখনো কোনো SMS নেই।")
            }
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(vm.messages, key = { it.id }) { sms ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp)) {
                            Text("প্রেরক: ${sms.sender}", style = MaterialTheme.typography.labelLarge)
                            Spacer(Modifier.height(4.dp))
                            Text(sms.body)
                            Spacer(Modifier.height(4.dp))
                            Text(sms.receivedAt, style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(
                "ডেভেলপমেন্ট সংস্করণ: API token ও HTTP সেটিংস প্রকাশ্যে ব্যবহারের জন্য নয়।",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.secondary
            )
        }
    }
}
