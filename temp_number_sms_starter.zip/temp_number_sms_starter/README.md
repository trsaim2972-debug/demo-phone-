# Temp Number SMS Inbox — starter project

Starter scaffold for an Android SMS inbox backed by Node.js + PostgreSQL. It is intended for numbers you own or are authorized to operate.

## Architecture
- Android: Kotlin + Jetpack Compose + Retrofit
- Backend: Node.js + Express
- Database: PostgreSQL
- SMS: an approved provider that supports inbound SMS and signed webhooks

## Important limitations
- This is starter code, not a production-ready service.
- The backend uses a **development bearer token** for the Android API. Replace it with real user authentication (for example, short-lived JWTs/OIDC) before any real users or real SMS.
- The generic webhook uses a shared-secret header as a placeholder. Use the SMS provider's official signature-verification scheme in production; do not trust arbitrary public webhook requests.
- Provider APIs and number availability vary by country and provider. Confirm that your provider permits your intended use.
- Never expose one user's SMS to another user. OTPs are sensitive; apply access controls, retention limits, rate limits, and audit logging.
- Do not use this app to intercept other people's messages or bypass another service's account verification.

## Backend setup
Requires Node.js 20+ and PostgreSQL.

1. Create a database, e.g. `temp_sms`.
2. Copy `backend/.env.example` to `backend/.env` and set values.
3. In `backend/` run:
   ```sh
   npm install
   npm run migrate
   npm start
   ```
4. For local Android emulator, API base URL is `http://10.0.2.2:3000/`.
   For a physical phone, use your computer's LAN IP and keep the phone/computer on the same trusted network.
5. Use HTTPS for any deployment. Do not expose the development server publicly.

## Add a real SMS provider
Configure your provider to send inbound-message webhooks to:
`POST https://YOUR_HOST/webhooks/inbound-sms`

Expected JSON body:
```json
{
  "providerMessageId": "provider-message-id",
  "to": "+15551234567",
  "from": "+15557654321",
  "body": "Example incoming message",
  "receivedAt": "2026-01-01T12:00:00.000Z"
}
```
The sample checks `X-Webhook-Secret` against `WEBHOOK_SHARED_SECRET`. This is only a generic placeholder. Adapt the route to the provider's official signature validation and payload schema before production.

## Android setup
Open `android/` in Android Studio. If Android Studio asks to create a Gradle wrapper, let it do so. Set `API_BASE_URL` in `android/app/build.gradle.kts`:
- Emulator: `http://10.0.2.2:3000/`
- Physical device: `http://YOUR_COMPUTER_LAN_IP:3000/`

For local development only, the manifest enables cleartext HTTP. For release builds, remove that and use HTTPS.

The sample token `dev-demo-token` is for local development only. The backend and Android sample must use the same `DEV_API_TOKEN` value. Replace this simplistic setup with real authentication before production.
