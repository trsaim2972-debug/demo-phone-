require("dotenv").config();
const { pool } = require("./db");

async function main() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS sms_numbers (
      id BIGSERIAL PRIMARY KEY,
      phone_number TEXT NOT NULL UNIQUE,
      label TEXT NOT NULL DEFAULT '',
      active BOOLEAN NOT NULL DEFAULT TRUE,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );

    CREATE TABLE IF NOT EXISTS inbound_messages (
      id BIGSERIAL PRIMARY KEY,
      provider_message_id TEXT UNIQUE,
      number_id BIGINT NOT NULL REFERENCES sms_numbers(id) ON DELETE CASCADE,
      sender TEXT NOT NULL,
      body TEXT NOT NULL,
      received_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );

    CREATE INDEX IF NOT EXISTS inbound_messages_number_received_idx
      ON inbound_messages(number_id, received_at DESC);
  `);
  console.log("Database migration complete.");
  await pool.end();
}

main().catch(async (err) => {
  console.error(err);
  await pool.end();
  process.exit(1);
});
