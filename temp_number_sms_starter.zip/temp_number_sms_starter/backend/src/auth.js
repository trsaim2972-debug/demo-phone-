// Development-only authentication. Replace with real per-user authentication
// and ownership/tenant checks before production.
function requireDevBearer(req, res, next) {
  const expected = process.env.DEV_API_TOKEN;
  if (!expected) {
    return res.status(500).json({ error: "DEV_API_TOKEN is not configured" });
  }
  const supplied = req.get("authorization") || "";
  if (supplied !== `Bearer ${expected}`) {
    return res.status(401).json({ error: "Unauthorized" });
  }
  next();
}

module.exports = { requireDevBearer };
