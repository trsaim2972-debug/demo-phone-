require("dotenv").config();
const express = require("express");
const helmet = require("helmet");
const { pool } = require("./db");
const { requireDevBearer } = require("./auth");

const app = express();
app.disable("x-powered-by");
if (process.env.TRUST_PROXY === "true") app.set("trust proxy", 1);
app.use(helmet());
app.use(express.json({ limit: "32kb" }));

app.get("/health", (_req, res) => res.json({ ok: true }));

// Development-only API: the same bearer token can see all configured numbers.
// Production must authenticate individual users and enforce number ownership.
app.get("/api/numbers", requireDevBearer, async (_req, res, next) => {
  try {
    const result = await pool.query(
      `SELECT id, phone_number AS "phoneNumber", label, active
       FROM sms_numbers WHERE active = TRUE ORDER BY id`
    );
    res.json({ numbers: result.rows });
  } catch (err) { next(err); }
});

app.get("/api/numbers/:id/messages", requireDevBearer, async (req, res, next) => {
  const numberId = Number(req.params.id);
  const limit = Math.min(Math.max(Number(req.query.limit) || 30, 1), 100);
  if (!Number.isSafeInteger(numberId) || numberId < 1) {
    return res.status(400).json({ error: "Invalid number id" });
  }
  try {
    const exists = await pool.query(
      "SELECT id FROM sms_numbers WHERE id = $1 AND active = TRUE", [numberId]
    );
    if (!exists.rowCount) return res.status(404).json({ error: "Number not found" });

    const result = await pool.query(
      `SELECT id, sender, body, received_at AS "receivedAt"
       FROM inbound_messages
       WHERE number_id = $1
       ORDER BY received_at DESC LIMIT $2`,
      [numberId, limit]
    );
    res.json({ messages: result.rows });
  } catch (err) { next(err); }
});

// Generic webhook example. In production, verify the SMS provider's official
// request signature (including timestamp/replay protection) before parsing data.
app.post("/webhooks/inbound-sms", async (req, res, next) => {
  const expected = process.env.WEBHOOK_SHARED_SECRET;
  if (!expected || req.get("x-webhook-secret") !== expected) {
    return res.status(401).json({ error: "Invalid webhook authentication" });
  }

  const { providerMessageId, to, from, body, receivedAt } = req.body || {};
  if (
    typeof to !== "string" || typeof from !== "string" ||
    typeof body !== "string" || body.length > 10000 ||
    (providerMessageId != null && typeof providerMessageId !== "string")
  ) {
    return res.status(400).json({ error: "Invalid message payload" });
  }

  try {
    const numberResult = await pool.query(
      "SELECT id FROM sms_numbers WHERE phone_number = $1 AND active = TRUE", [to]
    );
    if (!numberResult.rowCount) {
      // Do not disclose which numbers exist.
      return res.status(202).json({ accepted: false });
    }

    const date = receivedAt && !Number.isNaN(Date.parse(receivedAt))
      ? new Date(receivedAt) : new Date();

    await pool.query(
      `INSERT INTO inbound_messages
         (provider_message_id, number_id, sender, body, received_at)
       VALUES ($1, $2, $3, $4, $5)
       ON CONFLICT (provider_message_id) DO NOTHING`,
      [providerMessageId || null, numberResult.rows[0].id, from, body, date]
    );
    res.status(202).json({ accepted: true });
  } catch (err) { next(err); }
});

app.use((err, _req, res, _next) => {
  // Keep detailed errors in server logs only.
  console.error(err);
  res.status(500).json({ error: "Internal server error" });
});

const port = Number(process.env.PORT) || 3000;
app.listen(port, "0.0.0.0", () => console.log(`SMS backend listening on ${port}`));
