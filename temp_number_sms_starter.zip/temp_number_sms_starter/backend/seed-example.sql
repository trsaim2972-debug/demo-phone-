-- Optional: add a number that you own or are authorized to use.
-- Replace the example with your provider-assigned number.
INSERT INTO sms_numbers (phone_number, label)
VALUES ('+15551234567', 'Example authorized number')
ON CONFLICT (phone_number) DO NOTHING;
